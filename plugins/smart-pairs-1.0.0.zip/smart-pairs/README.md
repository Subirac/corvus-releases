# Smart pairs

Type the opening of a pair — `**`, `$`, `(` — and the closing is written too, with
the caret between them: `**|**`. The Bold, Italic, Underline, Strikethrough and
Highlight shortcuts do the same with nothing selected.

- **Tab** steps out past the closing, so you keep typing without the arrow keys.
  A snippet trigger typed just before Tab still expands first.
- **Shift-Tab** makes room inside the pair: `** | **`. Tab then steps over the room and the closing.
- **Backspace** in an empty pair takes both ends.
- With text selected, typing the first character of a pair wraps it.
- `$` is a regular pair; a second `$` makes `$$|$$` (display maths); `*` then `*` makes `**|**`,
  and `{` `+` `+` makes `{++|++}`. Typing the closing steps over it.

Off until you switch it on in **Settings ▸ Writing ▸ Smart pairs**. While it is on, Corvus's
own bracket closing stands aside: your list decides which brackets close.

## Your pairs

`~/.corvus/smart-pairs.txt`, one `prefix|suffix` per line (`\|` for a literal bar, `# ` for a
note), or **Manage pairs…** in Settings. Corvus writes the file the first time you switch the
feather on.

## What it will not do

It stays out of code, of a word you are typing inside (`2*3`, `5"`), of a line's first `*` (a
list bullet), and of anything a backslash escapes (`\{`, `\$`). It is stateless: every decision
is made from the text around the caret, and it only ever inserts ordinary characters, so the
document means the same to Corvus's parser as if you had typed them yourself.

Needs Corvus 0.5.6 or later (the editor hooks `onType`, `onFormat`, `bracketClosing`,
`bindKey` options, `inCode` and `userFile`).
