// @ts-check
//
// Smart pairs — type the OPENING of a pair (`**`, `$`, `(`) or press its
// shortcut (⌘B) and the closing is written too, with the caret between them:
// `**|**`. Tab steps out past the closing so you keep typing without reaching
// for the arrow keys; Shift-Tab makes room inside the pair (`** | **`).
// Built 2026-11-04 as a feather, on the editor hooks API 2 gained for it
// (`editor.onType`, `onFormat`, `bracketClosing`, `bindKey(…, {afterSnippets})`,
// `editor.inCode`, `corvus.userFile`).
//
// HOW IT WORKS, and why it cannot disturb parsing:
//
//   - It is STATELESS. Every decision is made from the text around the caret
//     (`before`, the paragraph so far; `after`, the rest of the line), so there
//     is no record of "pairs I wrote" to drift from the document when the author
//     edits, undoes, or has the file changed under them.
//   - It only ever makes ORDINARY edits to the text — a few characters inserted
//     at the caret — and Corvus parses the document as it reads. It never sees
//     the document's grammar: `rawContainers.ts` reads the brackets of a
//     `::: name[t]{0.4\linewidth}` line when it RENDERS, from the text, and
//     whatever is typed there arrives as the same text it would have been.
//     Where typing a closing would leave a group unbalanced, the rules below
//     stay out: a backslash before an opener (`\{`, `\$`) is an escape, not an
//     opener, and nothing is paired inside code.
//
// The pairs are the author's: `~/.corvus/smart-pairs.txt`, one `prefix|suffix`
// per line (`corvus.userFile`). Settings ▸ Writing has the switch (off until
// asked for) and Manage pairs…, a list editor.

/** @typedef {{ prefix: string, suffix: string }} Pair */

export const FILE = 'smart-pairs.txt'

/** What a first-time author gets: Markdown marks, maths, CriticMarkup, brackets. */
export const DEFAULT_PAIRS = /** @type {Pair[]} */ (
  [
    ['***', '***'],
    ['**', '**'],
    ['*', '*'],
    ['~~', '~~'],
    ['==', '=='],
    ['++', '++'],
    ['`', '`'],
    ['$$', '$$'],
    ['$', '$'],
    ['(', ')'],
    ['[', ']'],
    ['{', '}'],
    ['"', '"'],
    ['{++', '++}'],
    ['{--', '--}'],
    ['{~~', '~~}'],
    ['{==', '==}'],
    ['{>>', '<<}']
  ].map(([prefix, suffix]) => ({ prefix, suffix }))
)

const HEADER = `# Smart pairs. One pair per line, written prefix|suffix.
# Typing the prefix (or pressing its shortcut, such as ⌘B for **) writes the
# suffix too and leaves the caret between them. Tab jumps out past the suffix;
# Shift-Tab makes room inside the pair.
# A line that starts with "# " is a note. To use a | inside a prefix or suffix,
# write \\| instead.
`

// ---------- The file ----------

/** @param {string} line */
function firstBar(line) {
  for (let i = 0; i < line.length; i++) if (line[i] === '|' && line[i - 1] !== '\\') return i
  return -1
}
/** @param {string} s */
const unescapeBar = (s) => s.replace(/\\\|/g, '|')
/** @param {string} s */
const escapeBar = (s) => s.replace(/\|/g, '\\|')

/**
 * Reads the file. A line that is not a pair is reported, not guessed at.
 * @param {string} text
 * @returns {{ pairs: Pair[], problems: string[] }}
 */
export function parsePairs(text) {
  /** @type {Pair[]} */
  const pairs = []
  /** @type {string[]} */
  const problems = []
  const seen = new Set()
  text.split(/\r?\n/).forEach((raw, i) => {
    if (raw.trim() === '' || raw === '#' || raw.startsWith('# ')) return
    const cut = firstBar(raw)
    if (cut < 0) {
      problems.push(`line ${i + 1}: “${raw}” has no | between prefix and suffix`)
      return
    }
    const prefix = unescapeBar(raw.slice(0, cut))
    const suffix = unescapeBar(raw.slice(cut + 1))
    if (!prefix || !suffix) {
      problems.push(`line ${i + 1}: both sides of | need something`)
      return
    }
    if (seen.has(prefix)) {
      problems.push(`line ${i + 1}: “${prefix}” is already a prefix above`)
      return
    }
    seen.add(prefix)
    pairs.push({ prefix, suffix })
  })
  return { pairs, problems }
}

/** @param {readonly Pair[]} pairs */
export function serializePairs(pairs) {
  return HEADER + pairs.map((p) => `${escapeBar(p.prefix)}|${escapeBar(p.suffix)}`).join('\n') + '\n'
}

// ---------- The rules ----------

const WORD = /[\p{L}\p{N}]/u
/** @param {string} ch */
const isWord = (ch) => ch !== '' && WORD.test(ch)

/** Longest prefix first, so `**` is tried before `*`. @param {readonly Pair[]} pairs */
const byPrefix = (pairs) => [...pairs].sort((a, b) => b.prefix.length - a.prefix.length)
/** @param {readonly Pair[]} pairs */
const bySuffix = (pairs) => [...pairs].sort((a, b) => b.suffix.length - a.suffix.length)

/**
 * @param {string} text
 * @param {string} token
 */
function occurrences(text, token) {
  let count = 0
  for (let at = text.indexOf(token); at >= 0; at = text.indexOf(token, at + token.length)) count++
  return count
}

/**
 * The part of `before` a pair is judged by: its own line, except for maths,
 * whose display form runs over lines. A whole paragraph would count a list's
 * `*` bullets as open emphasis.
 * @param {string} before
 * @param {Pair} pair
 */
function windowFor(before, pair) {
  if (pair.prefix.includes('$')) return before
  const line = before.slice(before.lastIndexOf('\n') + 1)
  // A line's leading `*` is a bullet, not an opened emphasis.
  return pair.prefix.includes('*') ? line.replace(/^\s*\*(?=\s|$)/, '') : line
}

/**
 * Whether `before` leaves `pair` open.
 * @param {string} before
 * @param {Pair} pair
 */
export function isInside(before, pair) {
  const text = windowFor(before, pair)
  if (pair.prefix === pair.suffix) return occurrences(text, pair.prefix) % 2 === 1
  return occurrences(text, pair.prefix) > occurrences(text, pair.suffix)
}

/**
 * The pair that typing `typed` after `before` opens, or null. The guards keep
 * it from being a nuisance in prose: not in front of a word; a pair whose ends
 * are alike does not open after a word (`2*3`, `5"`); a line's first `*` is a
 * bullet; a closing typed by hand into an open pair is a closing; and a
 * backslash before the opener makes it an escape (`\{`, `\$`).
 * @param {string} before the paragraph so far
 * @param {string} typed
 * @param {string} after the rest of the line
 * @param {readonly Pair[]} pairs
 * @returns {Pair | null}
 */
export function pairOpenedBy(before, typed, after, pairs) {
  const text = before + typed
  if (pairs.some((p) => p.suffix.startsWith(typed) && isInside(before, p))) return null
  for (const pair of byPrefix(pairs)) {
    if (!text.endsWith(pair.prefix)) continue
    const start = text.length - pair.prefix.length
    if (isWord(after.charAt(0))) continue
    if (after.startsWith(typed) && pair.prefix === pair.suffix) continue
    if (pair.prefix === pair.suffix && isWord(text.charAt(start - 1))) continue
    if (text.charAt(start - 1) === '\\' && !pair.prefix.startsWith('\\')) continue
    if (pair.prefix === '*' && text.slice(text.lastIndexOf('\n') + 1, start).trim() === '') continue
    return pair
  }
  return null
}

/**
 * The caret is in an EMPTY pair (or one with a few marks in it) and the typed
 * character makes a longer opener: `*|*` + `*` is `**`, `{|}` + `+` `+` is
 * `{++`. Returns what to replace and what with.
 * @param {string} before
 * @param {string} typed
 * @param {string} after
 * @param {readonly Pair[]} pairs
 * @returns {{ back: number, forward: number, pair: Pair } | null}
 */
export function extensionBy(before, typed, after, pairs) {
  for (const p of byPrefix(pairs)) {
    if (!after.startsWith(p.suffix)) continue
    for (let k = 0; k <= 6; k++) {
      const head = before.slice(Math.max(0, before.length - p.prefix.length - k))
      if (!head.startsWith(p.prefix) || head.length !== p.prefix.length + k) continue
      const inner = head.slice(p.prefix.length)
      if (inner.includes(' ')) continue
      const wanted = p.prefix + inner + typed
      const longer = pairs.find((q) => q.prefix === wanted)
      if (longer) return { back: head.length, forward: p.suffix.length, pair: longer }
    }
  }
  return null
}

/**
 * Typing the closing steps over it: how many characters of the suffix are
 * already behind the caret, so that `typed` is the next one. Null when it is
 * not a closing of a pair the caret is inside.
 * @param {string} before
 * @param {string} typed
 * @param {string} after
 * @param {readonly Pair[]} pairs
 */
export function overtypes(before, typed, after, pairs) {
  for (const p of bySuffix(pairs)) {
    for (let j = 0; j < p.suffix.length; j++) {
      const rest = p.suffix.slice(j)
      if (!rest.startsWith(typed) || !after.startsWith(rest)) continue
      if (j > 0 && !before.endsWith(p.suffix.slice(0, j))) continue
      if (isInside(before.slice(0, before.length - j), p)) return j
    }
  }
  return null
}

/**
 * How many characters Tab jumps over: any spaces the caret stands in front of
 * (the room Shift-Tab made) and then the suffix of a pair the caret is inside.
 * Null when it is inside none, which leaves Tab to its other uses.
 * @param {string} before
 * @param {string} after
 * @param {readonly Pair[]} pairs
 * @returns {number | null}
 */
export function tabJump(before, after, pairs) {
  const spaces = /^ */.exec(after)?.[0].length ?? 0
  const rest = after.slice(spaces)
  for (const pair of bySuffix(pairs)) {
    if (!rest.startsWith(pair.suffix) || !isInside(before, pair)) continue
    // Room made inside the pair is made on both sides: the opener has it too.
    if (spaces > 0) {
      const text = windowFor(before, pair)
      const lead = text.slice(text.lastIndexOf(pair.prefix) + pair.prefix.length)
      if (!lead.startsWith(' '.repeat(spaces))) continue
    }
    return spaces + pair.suffix.length
  }
  return null
}

/**
 * The adjacent empty pair around the caret, for Backspace to take away whole.
 * @param {string} before
 * @param {string} after
 * @param {readonly Pair[]} pairs
 */
export function emptyPairAround(before, after, pairs) {
  for (const pair of byPrefix(pairs)) {
    if (before.endsWith(pair.prefix) && after.startsWith(pair.suffix)) return pair
  }
  return null
}

// ---------- In Corvus ----------

/**
 * @param {import('../corvus-plugin').CorvusEditor} editor
 */
function around(editor) {
  const pos = editor.caret
  const line = editor.lineAt(pos)
  const start = Math.max(0, pos - 4000)
  const raw = editor.text(start, pos)
  const blank = /\n[ \t]*\n(?![\s\S]*\n[ \t]*\n)/.exec(raw)
  return {
    pos,
    before: blank ? raw.slice(blank.index + blank[0].length) : raw,
    after: editor.text(pos, Math.min(line.to, pos + 200))
  }
}

/** @param {import('../corvus-plugin').CorvusEditor} editor */
const single = (editor) => editor.selections.length === 1 && editor.selections[0].from === editor.selections[0].to

/** @param {import('../corvus-plugin').CorvusPluginApi} corvus */
export function register(corvus) {
  const editorApi = corvus.editor
  if (typeof editorApi.onType !== 'function' || typeof editorApi.onFormat !== 'function') {
    corvus.log('this Corvus is too old for Smart pairs (it needs editor.onType and editor.onFormat)')
    return
  }
  const file = typeof corvus.userFile === 'function' ? corvus.userFile(FILE) : null
  /** @type {Pair[]} */
  let pairs = DEFAULT_PAIRS
  const enabled = () => corvus.settings.get('enabled') === 'true'

  const loadPairs = async () => {
    try {
      const text = await file?.read()
      if (typeof text === 'string') pairs = parsePairs(text).pairs
    } catch (err) {
      corvus.log('could not read the pairs file:', err)
    }
  }
  void loadPairs()
  window.addEventListener('focus', () => void loadPairs())

  // Corvus's own bracket closing steps aside while this is on: the author's
  // list decides which brackets close, and two writers would close twice.
  const applyEnabled = () => {
    editorApi.bracketClosing?.(!enabled())
  }
  applyEnabled()
  corvus.settings.onChange?.('enabled', () => {
    applyEnabled()
    // The first time, write the file so it sits beside shortcuts.json to be edited.
    if (enabled() && file) {
      void file.read().then((text) => (text === null ? file.write(serializePairs(pairs)) : undefined))
    }
  })

  editorApi.onType((typed, editor) => {
    if (!enabled() || pairs.length === 0) return null
    const { from, to, text } = typed
    if (editor.inCode?.(from)) return null
    // A selection plus the first character of a pair wraps it.
    if (from !== to) {
      const pair = pairs.find((p) => p.prefix === text)
      if (!pair) return null
      return {
        changes: [
          { from, insert: pair.prefix },
          { from: to, insert: pair.suffix }
        ],
        select: { from: from + pair.prefix.length, to: to + pair.prefix.length }
      }
    }
    const { before, after } = around(editor)
    const longer = extensionBy(before, text, after, pairs)
    if (longer) {
      const start = from - longer.back
      return {
        changes: [{ from: start, to: from + longer.forward, insert: longer.pair.prefix + longer.pair.suffix }],
        select: { from: start + longer.pair.prefix.length, to: start + longer.pair.prefix.length }
      }
    }
    if (overtypes(before, text, after, pairs) !== null) {
      return { changes: [], select: { from: from + 1, to: from + 1 } }
    }
    const pair = pairOpenedBy(before, text, after, pairs)
    if (!pair) return null
    return { changes: [{ from, insert: text + pair.suffix }], select: { from: from + 1, to: from + 1 } }
  })

  // Bold, Italic… with nothing selected: write the pair, or take an empty one back.
  editorApi.onFormat((format, editor) => {
    if (!enabled() || !single(editor)) return false
    const pair = pairs.find((p) => p.prefix === format.mark && p.suffix === format.mark)
    if (!pair) return false
    const { pos, before, after } = around(editor)
    if (before.endsWith(pair.prefix) && after.startsWith(pair.suffix)) {
      editor.change([{ from: pos - pair.prefix.length, to: pos + pair.suffix.length }])
      return true
    }
    if (!format.canStart || editor.inCode?.(pos)) return false
    const at = pos + pair.prefix.length
    editor.change([{ from: pos, insert: pair.prefix + pair.suffix }], { from: at, to: at })
    return true
  })

  // Tab steps out, after the snippet expander has had its say.
  editorApi.bindKey(
    'Tab',
    (editor) => {
      if (!enabled() || !single(editor)) return false
      const { pos, before, after } = around(editor)
      const skip = tabJump(before, after, pairs)
      if (skip === null) return false
      editor.select(pos + skip)
      return true
    },
    { afterSnippets: true }
  )
  editorApi.bindKey('Shift-Tab', (editor) => {
    if (!enabled() || !single(editor)) return false
    const { pos, before, after } = around(editor)
    if (tabJump(before, after, pairs) === null) return false
    editor.change([{ from: pos, insert: '  ' }], { from: pos + 1, to: pos + 1 })
    return true
  })
  editorApi.bindKey('Backspace', (editor) => {
    if (!enabled() || !single(editor)) return false
    const { pos, before, after } = around(editor)
    const pair = emptyPairAround(before, after, pairs)
    if (!pair) return false
    editor.change([{ from: pos - pair.prefix.length, to: pos + pair.suffix.length }])
    return true
  })

  // ---------- Settings: the list editor ----------
  /** @param {import('../corvus-plugin').PluginSettingsForm} form */
  const decorate = (form) => {
    const host = form.element
    if (host.querySelector('.sp-manage')) return
    const row = document.createElement('div')
    row.className = 'sp-manage'
    const info = document.createElement('span')
    info.className = 'sp-info'
    info.tabIndex = 0
    info.setAttribute('role', 'button')
    info.setAttribute('aria-label', 'About smart pairs')
    info.setAttribute('data-tip', 'Click to manage smart pairs')
    info.textContent = 'ⓘ'
    const button = document.createElement('button')
    button.type = 'button'
    button.className = 'btn sp-button'
    button.textContent = 'Manage pairs…'
    const open = () => openManager()
    button.addEventListener('click', open)
    info.addEventListener('click', open)
    info.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') open()
    })
    const where = document.createElement('span')
    where.className = 'sp-where'
    where.textContent = file ? file.path : '~/.corvus/smart-pairs.txt'
    row.append(button, info, where)
    host.append(row)
  }
  corvus.settingsUi?.onOpen('pane:editing', decorate)
  corvus.settingsUi?.onOpen('dialog', decorate)

  /** @type {HTMLElement | null} */
  let manager = null
  function openManager() {
    if (manager) return
    const layer = editorApi.popupLayer()
    const scrim = document.createElement('div')
    scrim.className = 'sp-scrim'
    const panel = document.createElement('div')
    panel.className = 'sp-panel'
    panel.setAttribute('role', 'dialog')
    panel.setAttribute('aria-label', 'Smart pairs')
    scrim.append(panel)
    manager = scrim

    const title = document.createElement('h3')
    title.textContent = 'Smart pairs'
    const intro = document.createElement('p')
    intro.className = 'sp-intro'
    intro.textContent =
      'Typing a prefix writes its suffix too and leaves the caret between them. Tab jumps out past the suffix; Shift-Tab makes room inside.'
    const list = document.createElement('div')
    list.className = 'sp-list'
    const note = document.createElement('p')
    note.className = 'sp-note'
    const foot = document.createElement('div')
    foot.className = 'sp-foot'

    /** @type {number | undefined} */
    let timer
    const rows = /** @type {{ prefix: HTMLInputElement, suffix: HTMLInputElement, el: HTMLElement }[]} */ ([])
    const current = () => rows.map((r) => ({ prefix: r.prefix.value, suffix: r.suffix.value }))
    const problem = () => {
      const seen = new Set()
      for (const p of current()) {
        if (!p.prefix || !p.suffix) return 'every pair needs both a prefix and a suffix'
        if (seen.has(p.prefix)) return `“${p.prefix}” is the prefix of two pairs`
        seen.add(p.prefix)
      }
      return null
    }
    const changed = () => {
      window.clearTimeout(timer)
      const bad = problem()
      note.textContent = bad ? `Not saved — ${bad}` : ''
      note.classList.toggle('sp-bad', Boolean(bad))
      if (bad) return
      timer = window.setTimeout(async () => {
        const next = current()
        pairs = next
        try {
          await file?.write(serializePairs(next))
          note.textContent = 'Saved'
        } catch (err) {
          note.textContent = `Could not save: ${err instanceof Error ? err.message : String(err)}`
          note.classList.add('sp-bad')
        }
      }, 450)
    }
    /** @param {Pair} pair */
    const addRow = (pair) => {
      const el = document.createElement('div')
      el.className = 'sp-row'
      const prefix = document.createElement('input')
      const suffix = document.createElement('input')
      for (const [input, value, label] of /** @type {const} */ ([
        [prefix, pair.prefix, 'Prefix'],
        [suffix, pair.suffix, 'Suffix']
      ])) {
        input.type = 'text'
        input.value = value
        input.spellcheck = false
        input.setAttribute('aria-label', label)
        input.addEventListener('input', changed)
      }
      const remove = document.createElement('button')
      remove.type = 'button'
      remove.className = 'sp-remove'
      remove.textContent = '×'
      remove.setAttribute('aria-label', 'Remove this pair')
      const entry = { prefix, suffix, el }
      remove.addEventListener('click', () => {
        rows.splice(rows.indexOf(entry), 1)
        el.remove()
        changed()
      })
      el.append(prefix, suffix, remove)
      rows.push(entry)
      list.append(el)
      return entry
    }
    const fill = (/** @type {readonly Pair[]} */ items) => {
      rows.length = 0
      list.replaceChildren()
      for (const pair of items) addRow(pair)
    }
    fill(pairs)

    const add = document.createElement('button')
    add.type = 'button'
    add.className = 'btn'
    add.textContent = 'Add pair'
    add.addEventListener('click', () => {
      addRow({ prefix: '', suffix: '' }).prefix.focus()
      list.scrollTop = list.scrollHeight
    })
    const reset = document.createElement('button')
    reset.type = 'button'
    reset.className = 'btn'
    reset.textContent = 'Reset to the usual pairs'
    reset.addEventListener('click', () => {
      fill(DEFAULT_PAIRS)
      changed()
    })
    const done = document.createElement('button')
    done.type = 'button'
    done.className = 'btn p'
    done.textContent = 'Done'
    const close = () => {
      window.clearTimeout(timer)
      scrim.remove()
      manager = null
      window.removeEventListener('keydown', onKey, true)
    }
    done.addEventListener('click', close)
    /** @param {KeyboardEvent} event */
    function onKey(event) {
      if (event.key !== 'Escape') return
      event.stopPropagation()
      close()
    }
    window.addEventListener('keydown', onKey, true)
    scrim.addEventListener('pointerdown', (event) => {
      if (event.target === scrim) close()
    })
    foot.append(add, reset, done)
    const path = document.createElement('p')
    path.className = 'sp-file'
    path.textContent = `Saved in ${file ? file.path : '~/.corvus/' + FILE}, one prefix|suffix per line.`
    panel.append(title, intro, list, note, foot, path)
    layer.append(scrim)
  }
}
