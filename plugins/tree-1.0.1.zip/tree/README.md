# Tree lists

A Corvus plugin. Put a nested list in a `tree` container and it is drawn as a
tree, its items joined by lines instead of bullets, in the Preview, the
exported HTML and the PDF:

```
::: tree **project/**
- `src/`
  - `main.ts`
- `docs/`
  1. Guide
  2. Reference
- `README.md`
:::
```

- The words after `tree` are the title: printed above the tree, the top level
  hanging from it. Without one, the top-level items are still joined by a line.
- A numbered list keeps its numbers; a checklist keeps its boxes; an item may
  hold **bold**, `code`, maths or a second paragraph.
- In the PDF a long tree breaks across pages between any two rows.
- A list inside a `::: note` inside an item is an ordinary list.

## Installing

Settings ▸ General ▸ Plugins ▸ **Install Plugin…**, and choose `tree-1.0.1.zip`.
It works at once; switching it off or removing it takes effect at the next launch.
Corvus 0.5.2 and later run only plugins its developer signed: this `.zip` carries
`signature.json`. Version 1.0.0 was not signed, so 0.5.2 refuses it; installing
1.0.1 over it replaces it.

## The files

| File | What it does |
| :-- | :-- |
| `plugin.json` | Name, version, and the plugin API it was written for. |
| `index.js` | Decides the tree's shape once, then draws it for the Preview and the PDF. |
| `preview.css` | The lines in the Preview, in every Preview Theme. |
| `preamble.tex` | The `CorvusTree` macros the PDF draws with; loaded only by a document with a tree. |
| `signature.json` | In the `.zip` only: the developer's signature over every file. |

How it was built, step by step, is in Corvus's `DEVELOPER-NOTES.md`, "Plugins".
