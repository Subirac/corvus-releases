# Math preview

A Corvus plugin. While the caret is inside maths — `$x + y$`, `$$\frac{a}{b}$$`,
or an environment written bare such as `\begin{align} … \end{align}` — a small
window shows the maths as the Preview will draw it, and redraws it as you type.

- It opens when the caret enters the maths and closes when the caret leaves.
- **Escape** closes it; it stays closed until the caret leaves that maths.
- **Drag** it anywhere. It opens there from then on, even after a relaunch.
  Until you drag it, it sits just below the maths; **double-click** it to put
  it back there.
- A mistake in the maths shows in red, with KaTeX's message underneath.
- **View ▸ Show Math Preview** switches it off and on, and Corvus remembers.
  Give it a key in Settings ▸ Keyboard (under Plugins), or put its **Math**
  button on the toolbar with View ▸ Customize Toolbar.
- It follows View ▸ Zoom, and Corvus's light and dark.

## Installing

Needs Corvus 0.5.2 or later, which speaks plugin API 2; 0.5.1 refuses it
and says why. Corvus runs it because its developer signed it: the `.zip`
carries `signature.json`, and a file changed after signing is refused. Settings ▸ General ▸ Plugins ▸
**Install Plugin…**, and choose `math-preview-1.1.0.zip`. It works at once;
switching it off or removing it takes effect at the next launch.

## The files

| File | What it does |
| :-- | :-- |
| `plugin.json` | Name, version, and the plugin API it was written for. |
| `index.js` | Watches the caret, draws the maths with Corvus's KaTeX, and handles Escape and dragging. |
| `ui.css` | How the window looks. |
| `signature.json` | In the `.zip` only: the developer's signature over every file. |

How it was built is in Corvus's `DEVELOPER-NOTES.md`, "Plugins".
