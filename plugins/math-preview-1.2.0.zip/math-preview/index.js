// @ts-check
//
// Math preview — while the caret is inside `$…$`, `$$…$$` or a bare maths
// environment (`\begin{align}…`), a small window shows that maths as the
// Preview will draw it, and redraws it as it is typed. A tester's request,
// built 2026-10-22, starting simple:
//
//   - it opens when the caret ENTERS maths and closes when it LEAVES;
//   - Escape closes it, and it stays closed until the caret leaves that maths;
//   - it can be dragged anywhere, and opens wherever it was last dragged to.
//     Until then it sits just below the maths (above, when there is no room
//     below); a double-click puts it back there.
//
// HOW IT WORKS, in three parts — the shape of most editor plugins:
//
//   1. WATCH the editor (`corvus.editor.watch`). After every change Corvus
//      hands over the editor as it now is, and this plugin asks it whether the
//      caret is in maths (`editor.mathAt`). Corvus answers from its own parse,
//      the one the Preview renders by, so this plugin never decides what maths
//      is: `$5 and $6` is prose, and a `$` in code is code.
//   2. DRAW with Corvus's own KaTeX (`corvus.renderMath`), so the window shows
//      what the Preview shows, macros and chemistry included, into a window of
//      its own in `corvus.editor.popupLayer()`. `ui.css` styles it.
//   3. KEYS AND SETTINGS. Escape is `corvus.editor.bindKey`; where the window
//      was dragged to is kept with `corvus.settings`.
//   4. A COMMAND: View ▸ Show Math Preview (`corvus.commands.add`), a checkbox
//      that switches the window off and on, remembered with `corvus.settings`.
//      It has no key until the author gives it one in Settings ▸ Keyboard, and
//      a toolbar button the author can add with View ▸ Customize Toolbar.
//   5. A LIST (1.2.0): a Maths tab in the Navigation panel (`corvus.panels.add`)
//      lists every piece of maths in the document, drawn, with Window ▸ Maths
//      List to show and hide it. Edit ▸ Find ▸ Select Next / Previous Maths
//      step through them, and Format ▸ Wrap Selection in $ makes maths. The
//      list is Corvus's own (`editor.maths`), never a `$` scan of the text.
//      `editor.maths` is newer than Corvus 0.5.2, so in 0.5.2 the list says
//      so and the window still works.
//
// The window never takes focus: pressing on it is `preventDefault`ed, so the
// caret stays in the maths and the typing carries on while it is dragged.

/** @typedef {import('../corvus-plugin').CorvusPluginApi} CorvusPluginApi */
/** @typedef {import('../corvus-plugin').CorvusEditor} CorvusEditor */
/** @typedef {import('../corvus-plugin').MathSpan} MathSpan */
/** @typedef {import('../corvus-plugin').ScreenRect} ScreenRect */
/** The window's place, from the editor's top-left corner, once it has been dragged. @typedef {{ x: number, y: number }} Offset */
/** @typedef {{ width: number, height: number }} Size */

/** Between the maths and the window, in px. */
const GAP = 6
/** How far the window keeps from the edges of Corvus's window. */
const MARGIN = 8
/** A press that moves less than this is a click, not a drag. */
const DRAG_THRESHOLD = 3
/** The setting that holds the `Offset`. */
const OFFSET_KEY = 'offset'
/** The setting that holds View ▸ Show Math Preview: `"false"` when switched off. */
const SHOWN_KEY = 'shown'
/** Lucide's `square-sigma` (ISC licence), the Maths tab's icon. */
const LIST_ICON =
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
  'stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M16 8.9V7H8l4 5-4 ' +
  '5h8v-1.9"/></svg>'
/** Lucide's `sigma` (ISC licence), the toolbar button's icon. */
const SIGMA_ICON =
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
  'stroke-linecap="round" stroke-linejoin="round"><path d="M18 7V5a1 1 0 0 0-1-1H6.5a.5.5 0 0 0-.4.8l4.5 6a2 2 0 0 1 0 ' +
  '2.4l-4.5 6a.5.5 0 0 0 .4.8H17a1 1 0 0 0 1-1v-2"/></svg>'

/**
 * Keeps a box wholly inside the window, a margin from each edge.
 * @param {number} left @param {number} top @param {Size} box @param {Size} view
 */
export function clampToWindow(left, top, box, view) {
  const maxLeft = Math.max(MARGIN, view.width - box.width - MARGIN)
  const maxTop = Math.max(MARGIN, view.height - box.height - MARGIN)
  return { left: Math.min(Math.max(left, MARGIN), maxLeft), top: Math.min(Math.max(top, MARGIN), maxTop) }
}

/**
 * Where the window goes before it has been dragged: below the maths, its left
 * edge under the maths' first character — or above, when below there is no room.
 * @param {ScreenRect} start where the maths begins @param {ScreenRect} end where it ends
 * @param {Size} box the window @param {Size} view Corvus's window
 */
export function besideMath(start, end, box, view) {
  const below = end.bottom + GAP
  const top = below + box.height <= view.height - MARGIN ? below : start.top - GAP - box.height
  return clampToWindow(start.left, top, box, view)
}

/**
 * The remembered place, or null for "beside the maths".
 * @param {string | null} stored @returns {Offset | null}
 */
export function parseOffset(stored) {
  try {
    const value = JSON.parse(stored ?? 'null')
    return value && Number.isFinite(value.x) && Number.isFinite(value.y) ? { x: value.x, y: value.y } : null
  } catch {
    return null
  }
}

/** Where the maths itself runs: inside its `$` or `$$`; a bare environment is all maths. @typedef {{ from: number, to: number }} Range */

/**
 * The inside of a piece of maths, from its text. An unclosed `$$` block (the
 * editor ends one at a blank line) runs to its end.
 * @param {MathSpan} span @param {(from: number, to: number) => string} text @returns {Range}
 */
export function insideOf(span, text) {
  const delimiter = text(span.from, span.from + 2) === '$$' ? '$$' : text(span.from, span.from + 1) === '$' ? '$' : ''
  if (!delimiter) return { from: span.from, to: span.to }
  const from = span.from + delimiter.length
  const closed = span.to - delimiter.length >= from && text(span.to - delimiter.length, span.to) === delimiter
  return { from, to: closed ? span.to - delimiter.length : span.to }
}

/**
 * The maths after (`1`) or before (`-1`) a selection, going round the document
 * at either end. The maths the caret is in is never the answer, so stepping
 * from one piece reaches the next even with its inside selected.
 * @param {readonly MathSpan[]} spans in document order @param {Range} selection @param {1 | -1} direction
 * @returns {MathSpan | null}
 */
export function stepMath(spans, selection, direction) {
  if (!spans.length) return null
  if (direction === 1) return spans.find((span) => span.from >= selection.to) ?? spans[0]
  for (let at = spans.length - 1; at >= 0; at--) if (spans[at].to <= selection.from) return spans[at]
  return spans[spans.length - 1]
}

/**
 * Wraps `selected` as maths: `$…$` in a line, `$$…$$` when it holds a line
 * break. Returns the text and where its inside is, from its start.
 * @param {string} selected @returns {{ text: string, inside: Range }}
 */
export function wrapAsMath(selected) {
  const delimiter = selected.includes('\n') ? '$$' : '$'
  return {
    text: delimiter + selected + delimiter,
    inside: { from: delimiter.length, to: delimiter.length + selected.length }
  }
}

/** @param {CorvusPluginApi} corvus */
export function register(corvus) {
  /** @type {HTMLElement | null} */ let dom = null
  /** @type {HTMLElement | null} */ let body = null
  /** @type {HTMLElement | null} */ let errorLine = null
  /** The maths on show, or null when the window is closed. @type {MathSpan | null} */
  let span = null
  /** What `body` holds, so an unchanged equation is not redrawn on every keystroke. */
  let drawn = ''
  /** Where the maths Escape closed begins; null when none is closed. @type {number | null} */
  let dismissedAt = null
  /** The editor as last seen, for placing the window outside a watch call. @type {CorvusEditor | null} */
  let editor = null
  let offset = parseOffset(corvus.settings.get(OFFSET_KEY))
  let shown = corvus.settings.get(SHOWN_KEY) !== 'false'
  /** @type {{ pointer: number, x: number, y: number, left: number, top: number, moved: boolean } | null} */
  let drag = null

  const windowSize = () => ({
    width: document.documentElement.clientWidth,
    height: document.documentElement.clientHeight
  })

  function build() {
    const box = document.createElement('div')
    box.className = 'corvus-math-preview'
    box.hidden = true
    box.setAttribute('aria-hidden', 'true')
    body = document.createElement('div')
    body.className = 'corvus-math-preview-body'
    errorLine = document.createElement('div')
    errorLine.className = 'corvus-math-preview-error'
    box.append(body, errorLine)
    // Keeps the focus — and the caret — in the editor.
    box.addEventListener('mousedown', (event) => event.preventDefault())
    box.addEventListener('pointerdown', onPointerDown)
    box.addEventListener('pointermove', onPointerMove)
    box.addEventListener('pointerup', onPointerUp)
    box.addEventListener('pointercancel', onPointerUp)
    box.addEventListener('dblclick', onDoubleClick)
    corvus.editor.popupLayer().appendChild(box)
    return box
  }

  function close() {
    span = null
    if (dom) dom.hidden = true
  }

  /** Moves the window to its remembered place, or beside the maths. */
  function place() {
    if (!dom || !span || !editor || drag) return
    const box = dom.getBoundingClientRect()
    const size = { width: box.width, height: box.height }
    if (offset) {
      const editorBox = editor.box
      const at = clampToWindow(editorBox.left + offset.x, editorBox.top + offset.y, size, windowSize())
      show(at.left, at.top)
      return
    }
    const start = editor.coordsAt(span.from, 1)
    const end = editor.coordsAt(span.to, -1)
    const visible = editor.visibleBox
    // Beside maths that has scrolled out of sight, the window would point at nothing.
    if (!start || !end || end.bottom < visible.top || start.top > visible.bottom) {
      dom.style.visibility = 'hidden'
      return
    }
    const at = besideMath(start, end, size, windowSize())
    show(at.left, at.top)
  }

  /** @param {number} left @param {number} top */
  function show(left, top) {
    if (!dom) return
    dom.style.left = `${left}px`
    dom.style.top = `${top}px`
    dom.style.visibility = ''
  }

  /** @param {CorvusEditor} now */
  function follow(now) {
    editor = now
    if (!shown) return close()
    // Away from the editor — another pane, another app — the window goes, but
    // an Escape still holds: coming back to the same maths keeps it closed.
    if (!now.hasFocus) return close()
    const found = now.mathAt(now.caret)
    if (!found) {
      // Out of the maths: the next maths, or this one entered again, opens it.
      dismissedAt = null
      return close()
    }
    if (dismissedAt !== null && dismissedAt !== found.from) dismissedAt = null
    if (dismissedAt !== null || !found.tex.trim()) return close()

    span = found
    if (!dom) dom = build()
    const key = `${found.display ? 'D' : 'I'}${found.tex}`
    if (key !== drawn && body && errorLine) {
      const { html, error } = corvus.renderMath(found.tex, found.display)
      body.innerHTML = html
      errorLine.textContent = error ?? ''
      errorLine.hidden = error === null
      drawn = key
    }
    // The editor's size, so the window follows View ▸ Zoom as the text does.
    dom.style.fontSize = now.fontSize
    if (dom.hidden) {
      // Laid out so it can be measured, painted only once it is placed.
      dom.style.visibility = 'hidden'
      dom.hidden = false
    }
    place()
  }

  /** Escape: close it until the caret leaves this maths. */
  function dismiss() {
    if (!span) return false
    dismissedAt = span.from
    close()
    return true
  }

  /** @param {PointerEvent} event */
  function onPointerDown(event) {
    if (event.button !== 0 || !dom) return
    event.preventDefault()
    const box = dom.getBoundingClientRect()
    drag = { pointer: event.pointerId, x: event.clientX, y: event.clientY, left: box.left, top: box.top, moved: false }
    try {
      // Keeps the drag when the pointer outruns the window.
      dom.setPointerCapture(event.pointerId)
    } catch {
      // A pointer the page no longer counts as down; the drag works without it.
    }
  }

  /** @param {PointerEvent} event */
  function onPointerMove(event) {
    if (!drag || event.pointerId !== drag.pointer || !dom) return
    const dx = event.clientX - drag.x
    const dy = event.clientY - drag.y
    if (!drag.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD) return
    if (!drag.moved) {
      drag.moved = true
      dom.classList.add('is-dragging')
    }
    const box = dom.getBoundingClientRect()
    const at = clampToWindow(drag.left + dx, drag.top + dy, { width: box.width, height: box.height }, windowSize())
    show(at.left, at.top)
  }

  /** @param {PointerEvent} event */
  function onPointerUp(event) {
    const done = drag
    if (!done || event.pointerId !== done.pointer || !dom) return
    drag = null
    dom.classList.remove('is-dragging')
    if (dom.hasPointerCapture(event.pointerId)) dom.releasePointerCapture(event.pointerId)
    if (!done.moved || !editor) return
    // Kept from the EDITOR's corner, so the window keeps its place beside the
    // text when a panel is pinned or Corvus's window is resized.
    const box = dom.getBoundingClientRect()
    const editorBox = editor.box
    offset = { x: Math.round(box.left - editorBox.left), y: Math.round(box.top - editorBox.top) }
    corvus.settings.set(OFFSET_KEY, JSON.stringify(offset))
  }

  /** @param {MouseEvent} event */
  function onDoubleClick(event) {
    event.preventDefault()
    offset = null
    corvus.settings.set(OFFSET_KEY, 'null')
    place()
  }

  // The Maths list. `listed` is what the tab holds (or would, when hidden):
  // the list is redrawn only when the maths changes, and a caret move only
  // moves the mark on the item it is in.
  /** @type {readonly MathSpan[]} */ let listed = []
  let listedKey = ''
  /** @type {HTMLElement | null} */ let listEl = null
  /** The list's drawn maths, kept so a redraw draws only what changed. @type {Map<string, { html: string, error: string | null }>} */
  let drawnItems = new Map()
  /** True when this Corvus can list maths (`editor.maths`, after 0.5.2). */
  let canList = true

  /** @param {CorvusEditor} now @returns {readonly MathSpan[] | null} */
  function mathsOf(now) {
    if (typeof now.maths !== 'function') {
      canList = false
      return null
    }
    return now.maths()
  }

  /** @param {CorvusEditor} now */
  function updateList(now) {
    const spans = mathsOf(now)
    if (!spans) return
    const key = spans.map((span) => `${span.from}:${span.to}:${span.display ? 'D' : 'I'}${span.tex}`).join('\n')
    if (key !== listedKey) {
      listed = spans
      listedKey = key
      list.setCount(spans.length)
      list.refresh()
    } else markCurrent(now.caret)
  }

  /** Marks the item the caret is in. @param {number} caret */
  function markCurrent(caret) {
    if (!listEl) return
    for (const item of listEl.querySelectorAll('[data-from]')) {
      const from = Number(/** @type {HTMLElement} */ (item).dataset.from)
      const to = Number(/** @type {HTMLElement} */ (item).dataset.to)
      item.classList.toggle('is-current', caret > from && caret < to)
    }
  }

  /** Selects the inside of a piece of maths, which opens the window on it. @param {CorvusEditor} now @param {MathSpan} span */
  function goTo(now, span) {
    const inside = insideOf(span, (from, to) => now.text(from, to))
    now.select(inside.from, inside.to)
    now.focus()
  }

  /** @param {HTMLElement} container @param {CorvusEditor | null} now */
  function renderList(container, now) {
    if (now) {
      const spans = mathsOf(now)
      if (spans) listed = spans
    }
    if (!canList) {
      container.append(note('This list needs a newer Corvus (0.5.3 or later). The math window works as before.'))
      return
    }
    if (!listed.length) {
      container.append(note('No maths in this document. Write $x^2$, $$…$$ or \\begin{align}…'))
      return
    }
    const keep = new Map()
    const items = document.createElement('ol')
    items.className = 'corvus-maths-list'
    for (const span of listed) {
      const key = `${span.display ? 'D' : 'I'}${span.tex}`
      const drawn = drawnItems.get(key) ?? corvus.renderMath(span.tex, span.display)
      keep.set(key, drawn)
      const item = document.createElement('li')
      const button = document.createElement('button')
      button.type = 'button'
      button.dataset.from = String(span.from)
      button.dataset.to = String(span.to)
      button.title = `Line ${now ? now.lineAt(span.from).number : '?'}: ${span.tex.trim()}`
      const line = document.createElement('span')
      line.className = 'corvus-maths-line'
      line.textContent = now ? String(now.lineAt(span.from).number) : ''
      const maths = document.createElement('span')
      maths.className = 'corvus-maths-item' + (drawn.error ? ' has-error' : '')
      if (drawn.error) maths.textContent = span.tex.trim()
      else maths.innerHTML = drawn.html
      button.append(line, maths)
      // A press would take the focus from the editor before the click lands.
      button.addEventListener('mousedown', (event) => event.preventDefault())
      button.addEventListener('click', () => {
        const editorNow = corvus.editor.current()
        if (editorNow) goTo(editorNow, span)
      })
      item.append(button)
      items.append(item)
    }
    drawnItems = keep
    container.append(items)
    listEl = items
    if (now) markCurrent(now.caret)
    return () => {
      listEl = null
    }
  }

  /** @param {string} text */
  function note(text) {
    const element = document.createElement('p')
    element.className = 'corvus-maths-note'
    element.textContent = text
    return element
  }

  const list = corvus.panels.add({
    id: 'maths',
    label: 'Maths',
    panel: 'navigation',
    icon: LIST_ICON,
    tip: 'Every piece of maths in the document',
    list: { label: 'Maths List', key: 'Mod-Alt-5' },
    render: renderList
  })

  corvus.editor.watch((now) => {
    follow(now)
    updateList(now)
  })
  corvus.editor.bindKey('Escape', dismiss)

  /** @param {CorvusEditor | null} now @param {1 | -1} direction */
  function step(now, direction) {
    if (!now) return
    const spans = mathsOf(now)
    const next = spans && stepMath(spans, now.selections[0], direction)
    if (next) goTo(now, next)
  }

  corvus.commands.add({
    id: 'next',
    label: 'Select Next Maths',
    menu: { path: ['Edit', 'Find'], after: 'find:previous' },
    key: 'Mod-Shift-y',
    run: (now) => step(now, 1)
  })
  corvus.commands.add({
    id: 'previous',
    label: 'Select Previous Maths',
    menu: { path: ['Edit', 'Find'], after: 'find:previous' },
    key: 'Mod-Alt-Shift-y',
    run: (now) => step(now, -1)
  })
  corvus.commands.add({
    id: 'wrap',
    label: 'Wrap Selection in $',
    menu: { path: ['Format'], after: 'format:highlight' },
    run(now) {
      if (!now) return
      const { from, to } = now.selections[0]
      const wrapped = wrapAsMath(now.text(from, to))
      now.change([{ from, to, insert: wrapped.text }], {
        from: from + wrapped.inside.from,
        to: from + wrapped.inside.to
      })
      now.focus()
    }
  })

  const showCommand = corvus.commands.add({
    id: 'show',
    label: 'Show Math Preview',
    menu: 'View',
    checked: shown,
    toolbar: { icon: SIGMA_ICON, label: 'Math', tip: 'Show Math Preview: the maths at the caret, drawn as you type' },
    run(now) {
      shown = !shown
      corvus.settings.set(SHOWN_KEY, String(shown))
      showCommand.setChecked(shown)
      if (!shown) close()
      else if (now) {
        // Switched back on with the caret already in maths: open at once.
        dismissedAt = null
        now.focus()
      }
    }
  })
}
