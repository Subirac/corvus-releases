# Header shift

Moves headings up or down one level.

- **Format ▸ Shift Selected Headers ▸ Left** (⌥⌘[) promotes: `### Title` becomes `## Title`.
- **Format ▸ Shift Selected Headers ▸ Right** (⌥⌘]) demotes: `## Title` becomes `### Title`.

It shifts every heading the selection touches, and the one on the caret's line, as one step
for Undo. A `## ` inside a code block is code and stays as it is. So does a `#` comment in
YAML front matter. Underlined headings shift too: `===` and `---` swap, and a `---` heading
shifted Right becomes `### Title`.

A command that would change nothing is dimmed: Left on a level-1 heading, Right on a level-6
one, either one in prose.

**Options…** (Settings ▸ General ▸ Plugins, on Header shift's row):

- *When a selected heading cannot move*: move none of them, so the outline keeps its shape
  (the default), or move the others.
- *Subheadings move with their heading*: off by default. When on, a shifted heading takes its
  section with it, up to the next heading of its level or higher.

The keys can be changed in Settings ▸ Keyboard, under Plugins.

Needs a Corvus newer than 0.5.6, which gives a document as elements (`editor.query`);
version 1.3.0 asked `editor.headings()`, newer than 0.5.5. In an older Corvus the commands do
nothing and the log says why.

It was built in the Plugin Course (`docs/Developer/Plugin-Course/01-header-shift/`), whose
tutorials rebuild it step by step.
