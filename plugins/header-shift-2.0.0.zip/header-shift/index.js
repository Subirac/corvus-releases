// @ts-check
//
// Header shift — moves headings up or down one level: Format ▸ Shift Selected
// Headers ▸ Left makes `### Title` a `## Title`, Right makes it `#### Title`.
// The developer's own design (plugins/header-shift/notes.md, 2026-10-28).
//
// HOW IT WORKS, in eight parts:
//
//   1. TWO COMMANDS (`corvus.commands.add`) in a submenu of the plugin's own at
//      the end of Format, with the keys ⌥⌘[ and ⌥⌘]. Settings ▸ Keyboard lists
//      them under Plugins, where the author can change them.
//   2. ASK CORVUS WHERE THE HEADINGS ARE. 0.1.0 found them with notes.md's
//      regular expressions, and its test showed what a regex cannot know: a
//      `## ` in a bash fence is a comment, `# x` in YAML front matter is not a
//      heading, and `> ### Quoted` is one. Corvus's answer comes from the parse
//      the editor colours by, so the plugin never decides what a heading is.
//      Since 2.0.0 the plugin asks for ELEMENTS (`editor.query('heading')`,
//      Plugin Course Module 3) rather than `editor.headings()`'s spans.
//   3. EVERY SELECTION (1.1.0): each range takes the headings on its lines, and
//      a caret the one on its own line. All of them shift as ONE change, one
//      step for Undo, and only their marks change: the title, an `{#id}` after
//      it and a quote's `>` before it are never touched.
//   4. AN OPTION (1.1.0, `settings.html`): when one of them cannot move (a
//      level-1 heading going Left), move none — so the outline keeps its
//      shape — or move the others. Corvus draws the control in an Options…
//      dialog and keeps its value; this file only reads it.
//   5. DIM WHAT WOULD DO NOTHING (1.1.0): a watcher (`corvus.editor.watch`)
//      works out, after every change, whether Left and Right would change
//      anything, and dims them when not (`setEnabled`). Corvus does not call a
//      dimmed command's `run`, so its key does nothing either.
//   6. SUBHEADINGS (1.2.0, a second option): a heading shifted can take its
//      section with it — the headings after it, up to the next one of its
//      level or higher — as an outliner moves a row with its children.
//   7. UNDERLINED HEADINGS (1.3.0): a title over `===` (level 1) or `---`
//      (level 2) shifts too. Until now they were left out; `shiftChange` is
//      the one function that learned them, because only it knows how a level
//      is written.
//   8. ELEMENTS (2.0.0): what 1.3.0 worked out for itself, Corvus now says.
//      The headings on a selection's lines are `editor.query('heading', lines)`;
//      a heading's subheadings are the headings in its `section()`; the run
//      that writes its level is its `heading-mark` child; its title is its
//      `text()`, and an `{#id}` after the title is its `attribute-block`.

/** @typedef {import('../corvus-plugin').CorvusPluginApi} CorvusPluginApi */
/** @typedef {import('../corvus-plugin').CorvusEditor} CorvusEditor */
/** A heading, as Corvus's element layer gives it (`editor.query('heading')`). @typedef {import('../corvus-plugin').CorvusElement} Heading */
/** @typedef {import('../corvus-plugin').TextChange} TextChange */
/** @typedef {import('../corvus-plugin').TextRange} TextRange */
/** @typedef {'left' | 'right'} Direction */
/** What to do when a heading cannot move: `none` moves nothing, `others` the rest. @typedef {'none' | 'others'} Blocked */

/** Where both commands go: a submenu of the plugin's own, at the end of Format. */
const MENU = /** @type {const} */ ({ path: ['Format', 'Shift Selected Headers'] })
/** settings.html's controls. */
const BLOCKED_KEY = 'blocked'
const SUBHEADINGS_KEY = 'subheadings'

/**
 * The level a heading goes to, or null when it cannot go that way: Left stops
 * at 1, Right at 6, the deepest heading Markdown has.
 * @param {number} level @param {Direction} direction
 */
export function shiftedLevel(level, direction) {
  const next = direction === 'left' ? level - 1 : level + 1
  return next >= 1 && next <= 6 ? next : null
}

/**
 * Where a heading's level is written: its opening `#`s, or its underline.
 * @param {Heading} heading
 */
export function levelMark(heading) {
  const marks = heading.children.filter((child) => child.kind === 'heading-mark')
  return heading.attrs.style === 'setext' ? marks[marks.length - 1] : marks[0]
}

/**
 * The change that shifts one heading, or null when it cannot move. A `##`
 * heading gains or loses a `#` at the front of its opening run. An underlined
 * one (1.3.0) has only two levels: its underline turns from `===` to `---` or
 * back, the same length, and a `---` heading going Right becomes `### Title`,
 * its lines joined, since no underline means level 3 — keeping an `{#id}`.
 * @param {Heading} heading @param {Direction} direction @returns {TextChange | null}
 */
export function shiftChange(heading, direction) {
  const level = shiftedLevel(/** @type {number} */ (heading.attrs.level), direction)
  const mark = levelMark(heading)
  if (level === null || !mark) return null
  if (heading.attrs.style === 'setext') {
    const { from, to } = mark
    if (level <= 2) return { from, to, insert: (level === 1 ? '=' : '-').repeat(to - from) }
    const block = heading.children.find((child) => child.kind === 'attribute-block')
    const title = heading.text().replace(/\s*\n\s*/g, ' ') + (block ? ` ${block.text()}` : '')
    return { from: heading.from, to: heading.to, insert: `${'#'.repeat(level)} ${title}` }
  }
  const at = mark.from
  return direction === 'left' ? { from: at, to: at + 1, insert: '' } : { from: at, insert: '#' }
}

/**
 * The headings a selection takes, in document order, each once: every heading
 * with a line in one of the ranges. A caret takes the heading on its own line.
 * A range ending at the very start of a line does not take that line — that is
 * where selecting whole lines leaves it. Corvus finds the headings in each
 * range (`query` with a range); the plugin only decides that it means lines.
 * @param {CorvusEditor} editor @param {readonly TextRange[]} ranges
 */
export function selectedHeadings(editor, ranges) {
  /** @type {Set<Heading>} */
  const taken = new Set()
  for (const range of ranges) {
    const last = range.to > range.from && editor.lineAt(range.to).from === range.to ? range.to - 1 : range.to
    const lines = { from: editor.lineAt(range.from).from, to: editor.lineAt(last).to }
    for (const heading of /** @type {NonNullable<CorvusEditor['query']>} */ (editor.query)('heading', lines)) taken.add(heading)
  }
  // An element is the same object each time it is asked for in one version,
  // so a Set keeps each heading once and the full list gives document order.
  return headingsOf(editor).filter((heading) => taken.has(heading))
}

/** Every heading in the document, in order. @param {CorvusEditor} editor */
function headingsOf(editor) {
  return /** @type {NonNullable<CorvusEditor['query']>} */ (editor.query)('heading')
}

/**
 * `targets` and each one's subheadings — the headings in its section, which
 * runs to the next heading of its level or higher — in document order, each once.
 * @param {CorvusEditor} editor @param {readonly Heading[]} targets
 */
export function withSubheadings(editor, targets) {
  const taken = new Set(targets)
  for (const target of targets) {
    const section = target.section()
    if (!section) continue
    for (const heading of headingsOf(editor)) if (heading.from > target.from && heading.from < section.to) taken.add(heading)
  }
  return headingsOf(editor).filter((heading) => taken.has(heading))
}

/**
 * The changes that shift `targets` one level, or none at all. With `blocked`
 * 'none', one heading that cannot move holds them all back.
 * @param {readonly Heading[]} targets @param {Direction} direction @param {Blocked} blocked
 * @returns {TextChange[]}
 */
export function planShift(targets, direction, blocked) {
  /** @type {TextChange[]} */
  const changes = []
  for (const heading of targets) {
    const change = shiftChange(heading, direction)
    if (change) changes.push(change)
    else if (blocked === 'none') return []
  }
  return changes
}

/** @param {CorvusPluginApi} corvus */
export function register(corvus) {
  /** @returns {Blocked} */
  const blocked = () => (corvus.settings.get(BLOCKED_KEY) === 'others' ? 'others' : 'none')

  /**
   * What `direction` would change in `editor` now — null when this Corvus
   * cannot give its elements (`editor.query` is newer than Corvus 0.5.6).
   * @param {CorvusEditor} editor @param {Direction} direction
   */
  function plan(editor, direction) {
    if (typeof editor.query !== 'function') return null
    const selected = selectedHeadings(editor, editor.selections)
    const targets = corvus.settings.get(SUBHEADINGS_KEY) === 'true' ? withSubheadings(editor, selected) : selected
    return planShift(targets, direction, blocked())
  }

  /** @param {CorvusEditor | null} editor @param {Direction} direction */
  function shift(editor, direction) {
    if (!editor) return
    const changes = plan(editor, direction)
    if (changes === null) corvus.log('this Corvus cannot say where the headings are: editor.query() is newer than Corvus 0.5.6')
    else if (changes.length) editor.change(changes)
  }

  const left = corvus.commands.add({ id: 'left', label: 'Left', menu: MENU, key: 'Mod-Alt-[', run: (editor) => shift(editor, 'left') })
  const right = corvus.commands.add({ id: 'right', label: 'Right', menu: MENU, key: 'Mod-Alt-]', run: (editor) => shift(editor, 'right') })

  // Dimming. The watcher is called after every change, the caret's moves
  // included, so the menu is told only when what it shows changes.
  /** @type {CorvusEditor | null} */ let latest = null
  let canLeft = true
  let canRight = true
  /** @param {CorvusEditor} editor */
  function dim(editor) {
    latest = editor
    const leftPlan = plan(editor, 'left')
    const rightPlan = plan(editor, 'right')
    // A Corvus that cannot say where the headings are leaves the menu alone; the command says why in the log.
    if (leftPlan === null || rightPlan === null) return
    if (canLeft !== leftPlan.length > 0) left.setEnabled((canLeft = leftPlan.length > 0))
    if (canRight !== rightPlan.length > 0) right.setEnabled((canRight = rightPlan.length > 0))
  }
  corvus.editor.watch(dim)

  // The author changed an option: what can run may have changed with it. The
  // editor as it is now, else as last seen (Settings may have the focus).
  const redim = () => {
    const editor = corvus.editor.current() ?? latest
    if (editor) dim(editor)
  }
  corvus.settings.onChange?.(BLOCKED_KEY, redim)
  corvus.settings.onChange?.(SUBHEADINGS_KEY, redim)
}
