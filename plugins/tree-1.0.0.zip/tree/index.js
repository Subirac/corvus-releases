// @ts-check
//
// Tree lists — `::: tree Title` draws the nested list inside it as a tree, its
// items joined by lines instead of bullets, in the Preview and in the PDF.
//
// The list is the author's own Markdown; the container only changes how it is
// drawn. Decisions (the owner's, 2026-10-21):
//   - the top level is ALWAYS joined by a line, with or without a title; a
//     title prints above and the line hangs from it;
//   - a numbered list keeps its numbers (`├── 1. Intro`).
//
// HOW IT WORKS, in three parts — the shape of most container plugins:
//
//   1. A markdown-it CORE RULE (`markTrees`) runs after Corvus has parsed the
//      document and decides the tree's shape ONCE, leaving it on the tokens:
//      which lists and items are the tree's, each item's row of columns, and
//      the numbers of a numbered list. Both outputs read that, so the Preview
//      and the PDF cannot draw different trees.
//   2. The PREVIEW wraps markdown-it's container renderer rules: a `tree`
//      becomes `<div class="tree-list">`, its lists keep their own `<ul>`/`<ol>`
//      and `preview.css` draws the lines with each item's pseudo-elements.
//   3. The PDF registers LaTeX handlers for the tokens it changes: no
//      itemize, each item a `CorvusTreeItem` row whose columns `preamble.tex`
//      draws.
//
// Column letters, one per level: `v` a line passing by (an ancestor with later
// siblings), `b` blank, `t` a tee (├), `l` the last item (└), `f` the first item
// of an untitled top level (┌), `a` an item alone at an untitled top level (──).

/** @typedef {import('../corvus-plugin').CorvusPluginApi} CorvusPluginApi */
/** @typedef {import('markdown-it/lib/token.mjs').default} Token */

/**
 * What this plugin leaves on a token's `meta`.
 * @typedef {{ tree?: boolean, treeContainer?: boolean, treeColumns?: string }} TreeMeta
 */

/** @param {Token} token @returns {TreeMeta} */
const metaOf = (token) => token.meta ?? {}

/** @param {Token} token @param {TreeMeta} extra */
function setMeta(token, extra) {
  token.meta = { ...(token.meta ?? {}), ...extra }
}

const LIST_OPEN = new Set(['bullet_list_open', 'ordered_list_open'])
const LIST_CLOSE = new Set(['bullet_list_close', 'ordered_list_close'])

/**
 * Index of the token closing the block opened at `open`: the next token of the
 * matching close type at the same nesting level.
 * @param {Token[]} tokens @param {number} open
 */
function closeOf(tokens, open) {
  const level = tokens[open].level
  const closeType = tokens[open].type.replace(/_open$/, '_close')
  for (let i = open + 1; i < tokens.length; i++) {
    if (tokens[i].type === closeType && tokens[i].level === level) return i
  }
  return tokens.length - 1
}

/**
 * The column letter of the item at `index` of `count` siblings.
 * @param {number} index @param {number} count @param {boolean} untitledTop
 */
function ownColumn(index, count, untitledTop) {
  const last = index === count - 1
  if (untitledTop && index === 0) return last ? 'a' : 'f'
  return last ? 'l' : 't'
}

/** @param {CorvusPluginApi} corvus */
export function register(corvus) {
  const md = corvus.markdownIt
  corvus.defineContainer('tree', 'A nested list drawn as a tree, with lines; the title is its root')

  // ---------- 1. The shape, decided once ----------

  /**
   * An ordered item's number goes into its first line, after any checkbox, so
   * the Preview and the PDF both print it with no help.
   * @param {Token[]} tokens @param {number} item @param {string} label
   * @param {new (type: string, tag: string, nesting: -1 | 0 | 1) => Token} TokenClass
   */
  function numberItem(tokens, item, label, TokenClass) {
    if (tokens[item + 1]?.type !== 'paragraph_open') return
    const inline = tokens[item + 2]
    if (inline?.type !== 'inline' || !inline.children) return
    const text = new TokenClass('text', '', 0)
    text.content = `${label} `
    const first = inline.children[0]
    const box = first?.type === 'html_inline' && /checkbox/.test(first.content)
    inline.children.splice(box ? 1 : 0, 0, text)
  }

  /**
   * Marks one list and its descendants. `ancestors` is the row of columns every
   * item of this list starts with.
   * @param {Token[]} tokens @param {number} open @param {string} ancestors
   * @param {boolean} untitledTop @param {any} TokenClass
   */
  function markList(tokens, open, ancestors, untitledTop, TokenClass) {
    const list = tokens[open]
    const close = closeOf(tokens, open)
    setMeta(list, { tree: true })
    setMeta(tokens[close], { tree: true })
    // Classes for preview.css: `tree` on every level, plus `tree-top` on the top
    // level and `tree-titled` when that level hangs from a title.
    list.attrJoin('class', ancestors === '' ? 'tree tree-top' : 'tree')
    if (ancestors === '' && !untitledTop) list.attrJoin('class', 'tree-titled')

    /** @type {number[]} */
    const items = []
    for (let i = open + 1; i < close; i++) {
      if (tokens[i].type === 'list_item_open' && tokens[i].level === list.level + 1) items.push(i)
    }
    const ordered = list.type === 'ordered_list_open'
    const start = Number(list.attrGet('start') ?? 1) || 1
    const delimiter = list.markup || '.'

    items.forEach((item, index) => {
      const own = ownColumn(index, items.length, untitledTop)
      setMeta(tokens[item], { tree: true, treeColumns: ancestors + own })
      const itemClose = closeOf(tokens, item)
      setMeta(tokens[itemClose], { tree: true })
      if (ordered) numberItem(tokens, item, `${start + index}${delimiter}`, TokenClass)
      // A line passes beside the children unless this item was the last.
      const childAncestors = ancestors + (own === 'l' || own === 'a' ? 'b' : 'v')
      // A list inside a container inside this item is that container's, not the
      // tree's, so only lists at depth 0 below the item are followed.
      let depth = 0
      for (let i = item + 1; i < itemClose; i++) {
        const t = tokens[i]
        if (t.type === 'container_callout_open') depth++
        else if (t.type === 'container_callout_close') depth--
        else if (depth === 0 && LIST_OPEN.has(t.type) && t.level === tokens[item].level + 1) {
          markList(tokens, i, childAncestors, false, TokenClass)
          i = closeOf(tokens, i)
        }
      }
    })
  }

  // PUSHED, so it runs LAST: after the inline parse and after the task-list rule
  // has put its checkbox in front of an item's text.
  md.core.ruler.push('tree_lists', (state) => {
    const tokens = state.tokens
    for (let open = 0; open < tokens.length; open++) {
      const token = tokens[open]
      if (token.type !== 'container_callout_open' || corvus.containerKind(token) !== 'tree') continue
      const close = closeOf(tokens, open)
      setMeta(token, { treeContainer: true })
      setMeta(tokens[close], { treeContainer: true })
      // The title is the root only of the list that FOLLOWS it; any later list
      // in the same container is a tree of its own.
      let titled = corvus.containerTitle(token) !== ''
      for (let i = open + 1; i < close; i++) {
        const t = tokens[i]
        if (t.type === 'container_callout_open') {
          i = closeOf(tokens, i)
          titled = false
          continue
        }
        if (LIST_CLOSE.has(t.type)) {
          titled = false
          continue
        }
        if (LIST_OPEN.has(t.type) && t.level === token.level + 1) {
          markList(tokens, i, '', !(titled && i === open + 1), state.Token)
          i = closeOf(tokens, i)
        }
        titled = false
      }
      // A tree nested in a tree is found by this loop in its turn.
    }
    return false
  })

  // ---------- 2. The Preview ----------

  // Wrap the container rules Corvus already has; every token that is not a
  // tree goes on to them unchanged.
  const openRule = md.renderer.rules.container_callout_open
  const closeRule = md.renderer.rules.container_callout_close
  if (!openRule || !closeRule) throw new Error('Corvus registered no container rules')

  md.renderer.rules.container_callout_open = (tokens, idx, options, env, self) => {
    const token = tokens[idx]
    if (!metaOf(token).treeContainer) return openRule(tokens, idx, options, env, self)
    token.attrJoin('class', 'tree-list')
    const title = corvus.containerTitle(token)
    // A fresh env for the title, as Corvus renders its own container titles.
    const titleLine = title ? `<p class="tree-title">${md.renderInline(title, {})}</p>\n` : ''
    // `renderAttrs` applies Corvus's attribute safety, so an author's
    // `{#id .class}` arrives and an `onclick` does not.
    return `<div${self.renderAttrs(token)}>\n${titleLine}`
  }
  md.renderer.rules.container_callout_close = (tokens, idx, options, env, self) =>
    metaOf(tokens[idx]).treeContainer ? '</div>\n' : closeRule(tokens, idx, options, env, self)

  // ---------- 3. The PDF ----------

  /**
   * One entry per open tree item: whether its `CorvusTreeItem` box is still open
   * (its children's list closes it, since they are rows of their own), how many
   * of its own paragraphs it has held, and the level those paragraphs are at.
   * @typedef {{ open: boolean, paragraphs: number, level: number }} Item
   */

  /** @param {Record<string, unknown>} state @returns {Item[]} */
  const itemsOf = (state) => /** @type {Item[]} */ ((state.items ??= []))

  /** Ends the innermost item's box if it is still open. @param {Record<string, unknown>} state */
  function closeBox(state) {
    const items = itemsOf(state)
    const item = items[items.length - 1]
    if (!item?.open) return ''
    item.open = false
    return '\\end{CorvusTreeItem}\n'
  }

  corvus.latex.on('container_callout_open', (token, latex) => {
    if (!metaOf(token).treeContainer) return undefined
    latex.usePreamble()
    const title = latex.renderInline(corvus.containerTitle(token))
    // The title is a row with no columns; the list's rows hang from it.
    return '\n\\begin{CorvusTree}\n' + (title ? `\\begin{CorvusTreeItem}{}${title}\\end{CorvusTreeItem}\n` : '')
  })
  corvus.latex.on('container_callout_close', (token) =>
    metaOf(token).treeContainer ? '\\end{CorvusTree}\n' : undefined
  )

  // A tree's lists draw no environment: each item is a row of its own, and the
  // children follow their parent's row. Returning '' (not undefined) is what
  // keeps Corvus from writing its itemize.
  for (const type of LIST_OPEN) {
    corvus.latex.on(type, (token, latex) => (metaOf(token).tree ? closeBox(latex.state) : undefined))
  }
  for (const type of LIST_CLOSE) {
    corvus.latex.on(type, (token) => (metaOf(token).tree ? '' : undefined))
  }

  corvus.latex.on('list_item_open', (token, latex) => {
    const columns = metaOf(token).treeColumns
    if (columns === undefined) return undefined
    itemsOf(latex.state).push({ open: true, paragraphs: 0, level: token.level + 1 })
    return `\\begin{CorvusTreeItem}{${columns}}`
  })
  corvus.latex.on('list_item_close', (token, latex) => {
    if (!metaOf(token).tree) return undefined
    const out = closeBox(latex.state)
    itemsOf(latex.state).pop()
    return out
  })

  // A loose item's second paragraph is a line of its own inside the same row.
  // Only the item's OWN paragraphs count, not those of a container inside it.
  corvus.latex.on('paragraph_open', (token, latex) => {
    const items = itemsOf(latex.state)
    const item = items[items.length - 1]
    if (item?.open && token.level === item.level && item.paragraphs++ > 0) return { before: '\\par' }
    return undefined
  })
}
